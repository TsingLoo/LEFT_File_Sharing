This is a template for the PhD confirmation report in School of Computing and Information Systems, The University of Melbourne.

It is the template I used for confirmation report, not an official one. 

I developed this based on the styles from https://github.com/kourgeorge/arxiv-style. Thanks for their contribution.

You can get the updated version of this template at https://github.com/oaimli/ConfirmationReportTemplate.

